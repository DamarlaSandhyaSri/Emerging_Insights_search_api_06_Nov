# convert all constants to upper case

TITAN_V1 = "amazon.titan-embed-text-v1"
TITAN_V2 = "amazon.titan-embed-text-v2:0"
EMBEDDING = "embedding"
NORMALIZE = "normalize"
APPLICATION_JSON = "application/json"
MAX_RETRIES = 3
RETRY_DELAY = 1
